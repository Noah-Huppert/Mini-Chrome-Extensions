window.location.href = $('#warningActions a').attr('href');
